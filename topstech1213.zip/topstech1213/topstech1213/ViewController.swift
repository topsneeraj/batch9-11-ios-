//
//  ViewController.swift
//  topstech1213
//
//  Created by TOPS on 6/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate,UIPickerViewDataSource,UIPickerViewDelegate {

    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var txt3: UITextField!
    @IBOutlet weak var txt1: UITextField!
    
    @IBOutlet weak var txt2: UITextField!
    
    @IBOutlet weak var dpicker: UIDatePicker!
    
    let arr = ["india","us","pak"];
    let arr1 = ["india1","us1","pak1","dfdf","sdfsfs"];
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        dpicker.isHidden = true;
        picker.isHidden = true;
         let dt = Date()
        getcurrentdate(dt: dt)
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 2;
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if component == 0 {
            
             return   arr.count;
            
        }
        else
        {
            return arr1.count
        }
       
    }
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if component == 0 {
            
             return arr[row];
        }
        else
        {
             return arr1[row];
        }
       
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if component == 0 {
            
            
            txt3.text = arr[row];
            picker.isHidden = true;

            
        }
        else
        {
            
            txt3.text = arr1[row];
            picker.isHidden = true;

        }
        
        
    }
    
    func getcurrentdate(dt:Date){
        
        
        let frm = DateFormatter();
        frm.dateFormat =  "dd-MM-yyyy";
        
        txt2.text = frm.string(from: dt)
        
        
        
    }
    @IBAction func dpickeraction(_ sender: Any) {
        
        
        let dt = dpicker.date;
        
        getcurrentdate(dt: dt)
        
        dpicker.isHidden = true;
        
        
        
        
    }
    func actionsheet(textfiled:UITextField)  {
        
        let alt = UIAlertController(title: "select", message: "select", preferredStyle: .actionSheet);
        
        let red = UIAlertAction(title: "Red", style: .default, handler: {action in
            
            textfiled.backgroundColor = UIColor.red;
            
            
            
        })
        
        let green = UIAlertAction(title: "Green", style: .default, handler: {action in
            
            textfiled.backgroundColor = UIColor.green;
            
        })
        
        let blue = UIAlertAction(title: "Blue", style: .default, handler: {action in
            
            textfiled.backgroundColor = UIColor.blue;
            
            
        })
        
        alt.addAction(red);
        alt.addAction(green);
        alt.addAction(blue);
        
        self.present(alt, animated: true, completion: nil);
        
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField.tag == 1 {
          
             actionsheet(textfiled: textField)
            
            return false;
            
        }
        else if(textField.tag == 3)
        {
            
            picker.isHidden = false;
            return false;
        }
        else
        {
            // actionsheet(textfiled: textField)
            dpicker.isHidden = false;
            
            return false;
        }
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.view.endEditing(true);
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

